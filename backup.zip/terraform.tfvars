aws_region                = "us-east-1"
databricks_external_id    = "6e79e9bf-db71-4dd8-bd1d-31253949fe77"
unity_catalog_external_id = "6e79e9bf-db71-4dd8-bd1d-31253949fe77"
enable_unity_catalog      = true
app_id   = "databricks-aws-tags" 
username = "krishna"  
unity_catalog_role_name     = "unity-catalog-role"